import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;

public class Book {
    private final SimpleStringProperty id;
    private final SimpleStringProperty title;
    private final SimpleStringProperty author;
    private final SimpleObjectProperty<BookStatus> status;

    public Book(String id, String title, String author, BookStatus status) {
        this.id = new SimpleStringProperty(id);
        this.title = new SimpleStringProperty(title);
        this.author = new SimpleStringProperty(author);
        this.status = new SimpleObjectProperty<>(status);
    }

    public String getId() {
        return id.get();
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public SimpleStringProperty idProperty() {
        return id;
    }

    public String getTitle() {
        return title.get();
    }

    public void setTitle(String title) {
        this.title.set(title);
    }

    public SimpleStringProperty titleProperty() {
        return title;
    }

    public String getAuthor() {
        return author.get();
    }

    public void setAuthor(String author) {
        this.author.set(author);
    }

    public SimpleStringProperty authorProperty() {
        return author;
    }

    public BookStatus getStatus() {
        return status.get();
    }

    public void setStatus(BookStatus status) {
        this.status.set(status);
    }

    public SimpleObjectProperty<BookStatus> statusProperty() {
        return status;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id='" + id.get() + '\'' +
                ", title='" + title.get() + '\'' +
                ", author='" + author.get() + '\'' +
                ", status=" + status.get() +
                '}';
    }
}