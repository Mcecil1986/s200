package com.example.s200project;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.application.Application.Parameters.*;



public class BookTracker<BookStatus> extends Application {

    private TableView<Book> tableView;
    private TextField idInput, titleInput, authorInput;
    private ComboBox<BookStatus> statusInput;
    private ObservableList<Book> bookList;

    @Override
    public void start(Stage primaryStage) {
        tableView = new TableView<>();
        bookList = FXCollections.observableArrayList();

        TableColumn<Book, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty());

        TableColumn<Book, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setCellValueFactory(cellData -> cellData.getValue().titleProperty());

        TableColumn<Book, String> authorColumn = new TableColumn<>("Author");
        authorColumn.setCellValueFactory(cellData -> cellData.getValue().authorinput());

        TableColumn<Book, BookStatus> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(cellData -> cellData.getValue().statusProperty());

        tableView.getColumns().addAll(idColumn, titleColumn, authorColumn, statusColumn);
        tableView.setItems(bookList);

        idInput = new TextField();
        idInput.setPromptText("ID");

        titleInput = new TextField();
        titleInput.setPromptText("Title");

        authorInput = new TextField();
        authorInput.setPromptText("Author");

        statusInput = new ComboBox<>();
        statusInput.setItems(FXCollections.observableArrayList(BookStatus.values()));
        statusInput.setPromptText("Status");

        Button addButton = new Button("Add Book");
        addButton.setOnAction(e -> addBook());

        Button deleteButton = new Button("Delete Book");
        deleteButton.setOnAction(e -> deleteBook());

        VBox layout = new VBox(10, idInput, titleInput, authorInput, statusInput, addButton, deleteButton, tableView);
        Scene scene = new Scene(layout, 600, 400);

        primaryStage.setTitle("Book Tracking App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void addBook() {
        String id = idInput.getText();
        String title = titleInput.getText();
        String author = authorInput.getText();
        BookStatus status = statusInput.getValue();

        if (!id.isEmpty() && !title.isEmpty() && !author.isEmpty() && status != null) {
            Book book = new Book(id, title, author, status);
            bookList.add(book);
            clearInputs();
        }
    }

    private void deleteBook() {
        Book selectedBook = tableView.getSelectionModel().getSelectedItem();
        if (selectedBook != null) {
            bookList.remove(selectedBook);
        }
    }

    private void clearInputs() {
        idInput.clear();
        titleInput.clear();
        authorInput.clear();
        statusInput.setValue(null);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
