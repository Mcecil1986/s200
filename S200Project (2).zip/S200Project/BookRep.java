// BookRepository.java
import java.util.List;

interface BookRepository {
    void addBook(Book book);
    List<Book> getBooks();
    Book findBookById(String id);
    void updateBook(Book book);
    void deleteBook(String id);
    List<Book> getBooksByStatus(BookStatus status);
}