// BookStatus.java
public enum BookStatus {
    COMPLETED,
    WANT_TO_READ,
    TO_BE_READ,
    DID_NOT_FINISH,

}