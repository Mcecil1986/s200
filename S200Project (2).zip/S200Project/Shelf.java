// InMemoryBookRepository.java
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Shelf implements BookRepository {
    private List<Book> books = new ArrayList<>();

    @Override
    public void addBook(Book book) {
        books.add(book);
    }

    @Override
    public List<Book> getBooks() {
        return new ArrayList<>(books);
    }

    @Override
    public Book findBookById(String id) {
        Optional<Book> book = books.stream().filter(b -> b.getId().equals(id)).findFirst();
        return book.orElse(null);
    }

    @Override
    public void updateBook(Book book) {
        int index = books.indexOf(findBookById(book.getId()));
        if (index >= 0) {
            books.set(index, book);
        }
    }

    @Override
    public void deleteBook(String id) {
        books.remove(findBookById(id));
    }

    @Override
    public List<Book> getBooksByStatus(BookStatus status) {
        return books.stream()
                .filter(book -> book.getStatus() == status)
                .collect(Collectors.toList());
    }
}